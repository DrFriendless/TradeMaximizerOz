import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: john
 * Date: 11/12/2010
 * Time: 12:17:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class WantList {
    private List<TradeRequest> wants;
    private Geeklist geeklist;
    private Map<String, Double> spendingLimits = new HashMap<String, Double>();

    WantList(List<TradeRequest> wants) {
        this.wants = wants;
        inferSpendingLimits();
    }

    private void inferSpendingLimits() {
        Map<String, Double> highestOffer = new HashMap<String, Double>();
        for (Iterator<TradeRequest> iter = wants.iterator(); iter.hasNext(); ) {
            TradeRequest request = iter.next();
            if (request.getItemName().equalsIgnoreCase("LIMIT")) {
                if (spendingLimits.containsKey(request.getUserName())) {
                    throw new RuntimeException("More than one spending limit for " + request.getUserName());
                }
                if (request.willAccept().size() > 1) {
                    throw new RuntimeException("Nonsense spending limit for " + request.getUserName());
                }
                spendingLimits.put(request.getUserName(), Money.parseMoney(request.willAccept().get(0)));
                iter.remove();
            } else if (request.isMoney()) {
                double m = request.getAmount();
                if (highestOffer.get(request.getUserName()) == null || m > highestOffer.get(request.getUserName())) {
                    highestOffer.put(request.getUserName(), m);
                }
            }
        }
        for (Map.Entry<String, Double> entry : highestOffer.entrySet()) {
            if (!spendingLimits.containsKey(entry.getKey())) {
                spendingLimits.put(entry.getKey(), entry.getValue());
            }
        }
    }

    public void setGeekList(Geeklist geeklist) {
        this.geeklist = geeklist;
    }

    public void check() {
        Set<String> names = new HashSet<String>();
        for (TradeRequest tr : wants) {
            if (names.contains(tr.getItemName())) throw new RuntimeException("Duplicate entry for " + tr.getItemName());
            names.add(tr.getItemName());
        }
        Map<String, Integer> numWant = new HashMap<String, Integer>();
        for (TradeRequest wantList : wants) {
            String user = wantList.getUserName();
            String userGame = wantList.getItemName();
            if (wantList.isDummy()) {
                // dummy item
            } else if (wantList.isMoney()) {
                // money
            } else {
                GeeklistItem userItem = checkGameExists(userGame, wantList, geeklist);
                if (userItem != null && !userItem.getUserName().equalsIgnoreCase(user.replace('#', ' '))) {
                    System.err.println("User submitted wants for an item which is not his: " + wantList);
                }
            }
            for (String name : wantList.willAccept()) {
                checkGameExists(name, wantList, geeklist);
                Integer c = numWant.get(name);
                if (c == null) c = 0;
                c = c + 1;
                numWant.put(name, c);
            }
        }
        List<Map.Entry<String, Integer>> entries = new ArrayList<Map.Entry<String, Integer>>(numWant.entrySet());
        Collections.sort(entries, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return -o1.getValue().compareTo(o2.getValue());
            }
        });
        System.out.println();
        System.out.println("MOST WANTED");
        for (Map.Entry<String, Integer> e : entries) {
            GeeklistItem item = geeklist.getItem(e.getKey());
            if (item == null) continue;
            System.out.println(item.getTradeCode() + ": " + item.getName() + " wanted in exchange for " + e.getValue() + " items");
        }
        System.out.println();
        // UNWANTED
        List<TradeRequest> unwanted = new ArrayList<TradeRequest>();
        for (TradeRequest tr : wants) {
            if (!numWant.keySet().contains(tr.getItemName()) && !tr.isDummy() && !tr.isMoney()) unwanted.add(tr);
        }
        Collections.sort(unwanted);
        System.out.println();
        System.out.println("UNWANTED");
        for (TradeRequest s : unwanted) {
            GeeklistItem item = geeklist.getItem(s.getItemName());
            if (item == null) {
                System.out.println("s = " + s.getItemName());
            } else {
                System.out.println(s.getItemName() + " " + item.getName());
            }
        }
    }

    private GeeklistItem checkGameExists(String code, TradeRequest wants, Geeklist geeklist) {
        if (code.startsWith("%") || code.startsWith("$")) return null;
        if (geeklist == null) return null;
        GeeklistItem item = geeklist.getItem(code);
        if (item == null) {
            System.err.println("Unknown game " + code + ": " + wants);
        }
        return item;
    }

    void showUnsubmitted() {
        List<String> allCodes = geeklist.getAllCodes();
        for (TradeRequest want : wants) {
            String itemName = want.getItemName();
            if (itemName.startsWith("%")) continue;
            if (itemName.startsWith("$")) continue;
            GeeklistItem item = geeklist.getItem(itemName);
            if (item == null) {
                System.out.println("WHAT IS item = " + itemName);
                continue;
            }
            allCodes.remove(item.getTradeCode());
        }
        List<String> lines = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        for (String code : allCodes) {
            GeeklistItem item = geeklist.getItem(code);
            lines.add("(" + item.getUserName() + ") " + item.getTradeCode() + ":");
            if (!names.contains(item.getUserName())) names.add(item.getUserName());
        }
        System.out.println();
        System.out.println("ITEMS FOR WHICH NO WANTS HAVE BEEN SUBMITTED (" + lines.size() + ")");
        Collections.sort(lines, new Comparator<String>() {
            public int compare(String o1, String o2) {
                return o1.compareToIgnoreCase(o2);
            }
        });
        for (String line : lines) System.out.println(line);
        Collections.sort(names);
        System.out.println();
        System.out.println("USERS WHO STILL HAVE TO SUBMIT WANTS (" + names.size() + ")");
        for (String line : names) System.out.println(line);
    }

    List<TradeRequest> getTradeRequests() {
        return new ArrayList<TradeRequest>(wants);
    }

    /**
     * Check the spending limits. If they've been exceeded, return the name of the person who did it by most.
     * @param paid
     * @return
     */
    public String satisfiesSpendingLimits(Map<String, Double> paid) {
        List<String> users = new ArrayList<String>();
        double most = 0;
        for (Map.Entry<String, Double>  entry : paid.entrySet()) {
            Double limit = spendingLimits.get(entry.getKey());
            if (limit == null) limit = 0.0;
            if (entry.getValue() - limit > most) {
                users.clear();
                most = entry.getValue() - limit;
            }
            if (entry.getValue() - limit == most && most > 0) {
                users.add(entry.getKey());
            }
        }
        Collections.sort(users);
        if (users.size() > 0) {
            System.out.println(users.get(0) + " exceeded spending limit by " + most);
            return users.get(0);
        }
        return null;
    }

    public void removeRequest(TradeRequest request) {
        wants.remove(request);
    }
}
